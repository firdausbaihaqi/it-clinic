-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 14 Bulan Mei 2020 pada 04.55
-- Versi server: 10.1.32-MariaDB
-- Versi PHP: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `order`
--

CREATE TABLE `order` (
  `id` int(11) NOT NULL,
  `code_order` int(11) NOT NULL,
  `customer` varchar(50) NOT NULL,
  `technician` varchar(50) NOT NULL,
  `image` varchar(255) NOT NULL,
  `detail` varchar(255) NOT NULL,
  `status` varchar(50) NOT NULL,
  `date_order` date NOT NULL,
  `date_finish` date NOT NULL,
  `price` varchar(50) NOT NULL,
  `shipment` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `order`
--

INSERT INTO `order` (`id`, `code_order`, `customer`, `technician`, `image`, `detail`, `status`, `date_order`, `date_finish`, `price`, `shipment`) VALUES
(26, 2147483647, 'andry', 'kiki', 'andry.jpg', 'rusak', 'finish', '2020-03-25', '2020-03-30', '5000', ''),
(27, 2147483647, 'andry', 'kiki', 'andry.png', 'iki kenopo to', 'history', '2020-03-25', '2020-04-06', '5000', 'delivered'),
(36, 343804281, 'andry', 'kiki', 'andry2.png', 'test3', 'in_progress', '2020-04-06', '0000-00-00', '', ''),
(37, 631091437, 'rizal', 'default', 'rizal.png', 'laptop mati, kadang bisa nyala tapi cuma sebentar habis itu mati lagi', 'finish', '2020-04-19', '2020-04-19', '', 'history'),
(38, 1901741171, 'rizal', 'default', 'rizal.jpg', 'wifi nya tidak bisa, keyboard ada beberapa tombol yang tidak berfungsi', 'history', '2020-04-19', '2020-04-19', '', 'history'),
(39, 1489732870, 'rizal', 'elsa', 'rizal1.png', 'engsel patah', 'history', '2020-04-19', '2020-04-19', '900000', 'history'),
(40, 1260046390, 'nyak', 'elsa', 'nyak.jpg', 'batrai consider', 'in_progress', '2020-05-03', '0000-00-00', '', ''),
(41, 355150646, 'wahyu', 'default', 'wahyu.png', 'Jatuh ketika mau dibawa kerja, kondisi hancur', 'in_queue', '2020-05-14', '0000-00-00', '', ''),
(42, 1971888661, 'wahyu', 'default', 'wahyu.jpg', 'Layar kadang bisa normal, kadang bergaris dan kadang juga blank hitam', 'available', '2020-05-14', '0000-00-00', '', ''),
(43, 646892771, 'keyla', 'default', 'keyla.jpg', 'Engsel kiri patah, kalo ada stocknya tolong diganti ya Pak/Mas jangan di repair', 'available', '2020-05-14', '0000-00-00', '', ''),
(44, 1164474769, 'keyla', 'default', 'keyla.png', 'Terakhir dibuat kerja habis itu dichas sampe full sambil dimatiin habis itu gabisa nyala', 'in_queue', '2020-05-14', '0000-00-00', '', ''),
(45, 1892917372, 'alan', 'default', 'alan.jpg', 'Laptop bisa nyala tapi layarnya cuman hitam', 'available', '2020-05-14', '0000-00-00', '', ''),
(46, 486334737, 'alan', 'default', 'alan1.jpg', 'Laptop panas sampe keluar asap', 'in_queue', '2020-05-14', '0000-00-00', '', ''),
(47, 1512187561, 'renata', 'default', 'renata.jpg', 'Tombo keyboard saya beberapa ilang abis dibuat mainan sama anak', 'available', '2020-05-14', '0000-00-00', '', ''),
(48, 1725563284, 'renata', 'default', 'laptoprusak8.png', 'tolong di cek in ya Pak abis ketumpahan kopi kira kira kalo diservice sampe berapa biayanya', 'in_queue', '2020-05-14', '0000-00-00', '', ''),
(49, 1522754871, 'raisa', 'default', 'raisa.jpg', 'tombol keyboard ilang gatau entah kemana Mas, tolong diganti aja ya', 'available', '2020-05-14', '0000-00-00', '', ''),
(50, 1084282921, 'raisa', 'default', 'raisa1.jpg', 'Gatau kenapa tiba-tiba waktu dinyalain gini terus layarnya biru', 'available', '2020-05-14', '0000-00-00', '', ''),
(51, 1800803192, 'putra', 'default', 'putra.jpg', 'Bang tolong benerin laptop saya bluefilm mulu layarnya', 'available', '2020-05-14', '0000-00-00', '', ''),
(52, 175153615, 'putra', 'default', 'putra1.jpg', 'Laptop temen ini dinyalain stack di logo terus dari ba\'da subuh sampe ba\'da isya', 'available', '2020-05-14', '0000-00-00', '', ''),
(53, 1052867003, 'rangga', 'default', 'rangga.jpg', 'Mas ini laptop saya tak nyalain tapi layarnya kok kyk mati gini ya', 'available', '2020-05-14', '0000-00-00', '', ''),
(54, 358643463, 'rangga', 'default', 'rangga.png', 'Ini punya adek saya juga kondisi nyala tapi layarnya kyk mati gitu', 'in_queue', '2020-05-14', '0000-00-00', '', ''),
(55, 1887318469, 'rizal', 'default', 'rizal1.jpg', 'Windows saya kok tiba-tiba desktopnya warna item gitu ya mas, nanti tolong dibenerin ya. Sama sekalian upgrade rame ddr3 8gb mas + installin android studio, SQL server, Virtualbox', 'available', '2020-05-14', '0000-00-00', '', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `user`, `password`, `image`, `status`) VALUES
(1, 'admin', 'admin', '', 'admin'),
(2, 'default', 'default', '', 'technician'),
(13, 'andry', '123', 'andry.jpg', 'customer'),
(15, 'kiki', '123', 'kiki.jpg', 'technician'),
(16, 'rizal', '123', 'rizal1.jpg', 'customer'),
(17, 'elsa', '123', 'elsa.jpg', 'technician'),
(18, 'nyak', '123', 'nyak.jpg', 'customer'),
(21, 'wahyu', '123', 'wahyu', 'customer'),
(22, 'Nino', '123', 'Nino', 'technician'),
(23, 'alan', '123', 'alan.png', 'customer'),
(24, 'raisa', '123', 'raisa.jpg', 'customer'),
(25, 'renata', '123', 'renata.jpg', 'customer'),
(26, 'keyla', '123', 'keyla.jpg', 'customer'),
(27, 'rangga', '123', 'rangga.jpg', 'customer'),
(28, 'putra', '123', 'putra.jpg', 'customer');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_customer`
--

CREATE TABLE `user_customer` (
  `id` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `image` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `phone` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user_customer`
--

INSERT INTO `user_customer` (`id`, `user`, `password`, `fullname`, `image`, `email`, `address`, `phone`) VALUES
(7, 'andry', '123', 'Andry Dwi S', 'andry.jpg', 'andry.dwi.s@gmail.com', 'Semanggi Barat no 25', '08986895328'),
(8, 'rizal', '123', 'Rizal Elsa Fanny', 'rizal1.jpg', 'kemplengrizal@gmail.com', 'Jl. Kuping Gajah No. 27 Malang', '085655695629'),
(9, 'nyak', '123', 'nyak ayu', 'nyak.jpg', 'adasdas@gmail.com', 'jl. jalan aja yuk', '10231923'),
(11, 'wahyu', '123', 'wahyu susilo', 'wahyu', 'wahyus@gmail.com', 'Desa Sukorejo Nganjuk', '08621318111'),
(12, 'alan', '123', 'Alan Surya Buana', 'alan.png', 'alansurya@gmail.com', 'JL. Semarang No. 97 Malang', '0851238840'),
(13, 'raisa', '123', 'Raisa Kumala Sari', 'raisa.jpg', 'raisari@gmail.com', 'JL. Pisang Kipas No. 26', '08772355990'),
(14, 'renata', '123', 'Renata Kusuma', 'renata.jpg', 'kusumarenata@gmail.com', 'JL. Simbar Menjangan No.45 Malang', '082134118500'),
(15, 'keyla', '123', 'Keyla Angelia', 'keyla.jpg', 'keyla.angel@gmail.com', 'JL. Siguragura No. 121 Malang', '081377231900'),
(16, 'rangga', '123', 'Rangga Messiano', 'rangga.jpg', 'ranggamessi@gmail.com', 'Perum Pondok Alam Blok A No. 19', '08561231882'),
(17, 'putra', '123', 'Syahputra Siregar', 'putra.jpg', 'siregarkuat@gmail.com', 'JL. Borobudur No. 77 Malang', '08921466178');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_technician`
--

CREATE TABLE `user_technician` (
  `id` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `image` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `education` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user_technician`
--

INSERT INTO `user_technician` (`id`, `user`, `password`, `fullname`, `image`, `email`, `address`, `phone`, `education`) VALUES
(1, 'default', 'default', '', '', '', '', '', ''),
(7, 'kiki', '123', 'kiki wibu', 'kiki.jpg', 'andry.dwi.s@gmail.com', 'malang', '123', 'SMA/SMK'),
(8, 'elsa', '123', 'elsa fanny', 'elsa.jpg', 'elsafann689@gmail.com', 'Nganjuk City', '0918213', 'SMA/SMK'),
(10, 'Nino', '123', 'Alnino', 'Nino', 'alnino@gmail.com', 'Ngawi', '0891247116', 'D1/D2');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer` (`customer`,`technician`),
  ADD KEY `technician` (`technician`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user` (`user`);

--
-- Indeks untuk tabel `user_customer`
--
ALTER TABLE `user_customer`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user` (`user`);

--
-- Indeks untuk tabel `user_technician`
--
ALTER TABLE `user_technician`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user` (`user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `order`
--
ALTER TABLE `order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT untuk tabel `user_customer`
--
ALTER TABLE `user_customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `user_technician`
--
ALTER TABLE `user_technician`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `order_ibfk_1` FOREIGN KEY (`customer`) REFERENCES `user_customer` (`user`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `order_ibfk_2` FOREIGN KEY (`technician`) REFERENCES `user_technician` (`user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `user_customer`
--
ALTER TABLE `user_customer`
  ADD CONSTRAINT `user_customer_ibfk_1` FOREIGN KEY (`user`) REFERENCES `user` (`user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `user_technician`
--
ALTER TABLE `user_technician`
  ADD CONSTRAINT `user_technician_ibfk_1` FOREIGN KEY (`user`) REFERENCES `user` (`user`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
